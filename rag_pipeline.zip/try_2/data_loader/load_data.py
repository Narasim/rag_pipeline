from typing import List
from langchain_community.document_loaders import PyMuPDFLoader
from langchain_community.document_loaders import csv_loader
from langchain_community.document_loaders import TextLoader
import os
from langchain.text_splitter import RecursiveCharacterTextSplitter


class DataLoader:
    """
    This class loads pdf, and txt files from a directory.
    Converts them to langchain documents.


    Args:
        directory_path: Folder path where pdf and txt files are stores
    """
    def __init__(self, directory_path: str):
        self.file_list = []
        self.docs = []
        self.data_directory = directory_path
        self.pdf_docs_loaders = []
        self.text_docs_loaders = []
    
    def get_file_list(self):
        """
        List all file names
        """
        return self.file_list
    
    def get_all_docs(self):
        """
        Get all the documents
        """
        return self.docs
    
    def collect_all_docs(self):
        """
        Collect all the documents
        """
        text_splitter = RecursiveCharacterTextSplitter(chunk_size = 1000, chunk_overlap = 200)
        for doc_loader in self.pdf_docs_loaders:
            for doc in doc_loader:
                self.docs.append(doc)
        for doc_loaders in self.text_docs_loaders:
            for doc in doc_loaders:
                self.docs.append(doc)
        self.docs = text_splitter.split_documents(documents = self.docs)

    def get_all_pdf_docs(self):
        """
        Get only pdf documents
        """
        temp_pdf_docs = []
        for doc_loader in self.pdf_docs_loaders:
            for doc in doc_loader:
                temp_pdf_docs.append(doc)
        return temp_pdf_docs
    
    def get_all_text_docs(self):
        """
        Get only text documents
        """
        temp_txt_docs = []
        for doc_loaders in self.text_docs_loaders:
            for doc in doc_loaders:
                temp_txt_docs.append(doc)

        return temp_txt_docs
    
    def get_data_directory(self):
        """
        Get the data directory path
        """
        return self.data_directory
    
    def create_loaders(self):
        """
        Instantiate pdf and txt loaders
        """
        self.file_list = os.listdir(self.data_directory)
        for file in self.file_list:
            if str(file).endswith('.pdf'):
                file_path = os.path.join(self.data_directory, file)
                pdf_loader = PyMuPDFLoader(file_path)
                self.pdf_docs_loaders.append(pdf_loader.load())
            elif str(file).endswith(".txt"):
                file_path = os.path.join(self.data_directory, file)
                text_loader = TextLoader(file_path)
                self.text_docs_loaders.append(text_loader.load())



# directory_path = '/home/genai/narasim_ai/practice/rag_pipeline/try_2/assets'
# loader_obj = DataLoader(directory_path)
# loader_obj.create_pdf_docs()
# all_docs = loader_obj.get_all_docs()



        
