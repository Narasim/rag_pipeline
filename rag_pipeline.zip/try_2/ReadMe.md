# RAG Pipeline Project

This project implements a Retrieval-Augmented Generation (RAG) pipeline using LangChain, LangGraph, OpenAI, and ChromaDB. It demonstrates an object-oriented approach for better code organization, maintainability, and scalability.

## Project Structure

rag_pipeline/
├── config/ # Configuration settings (API keys, constants)
│ ├── init.py
│ └── settings.py
├── lib/ # Core RAG components (document processing, embeddings, vector store, LLM service)
│ ├── init.py
│ └── rag_components.py
├── agent/ # RAG agent orchestration using LangGraph
│ ├── init.py
│ └── rag_agent.py
├── main.py # Main application entry point
├── requirements.txt # Python dependencies
├── README.md # Project overview and setup instructions
└── documentation/ # Additional project documentation
└── user_guide.md


## Features

*   **Object-Oriented Design:** Encapsulates different RAG functionalities into distinct classes.
*   **Modular Components:**
    *   `DocumentProcessor`: Handles web content loading and text splitting.
    *   `EmbeddingGenerator`: Manages OpenAI embeddings.
    *   `VectorStoreManager`: Interacts with ChromaDB for document storage and retrieval.
    *   `LLMService`: Manages LLM invocation and RAG prompt integration.
*   **LangGraph Integration:** Uses `langgraph` for defining the RAG workflow (retrieve -> generate).
*   **Configuration Management:** Separates API keys and settings using a `Settings` class.
*   **Persistent Vector Store:** Saves document embeddings locally using ChromaDB for faster subsequent runs.

## Setup and Running Instructions

Follow these steps to set up and run the RAG pipeline.

### Step 1: Clone the Repository (if applicable)

If this were a Git repository, you would clone it first. For this example, you'll create the files manually.

```bash
# If you were cloning:
# git clone <your-repo-url>
# cd rag_pipeline
```

### Step 2: Create the Project Structure and Files

Manually create the directories and files as described above, and paste the respective code into each file.

### Step 3: Create a Virtual Environment (Recommended)

It's good practice to use a virtual environment to manage dependencies.

```bash
python -m venv .venv
source .venv/bin/activate  # On Windows, use `.venv\Scripts\activate`
```

### Step 4: Install Dependencies

Install all required Python packages using the requirements.txt file.

```bash
pip install -r requirements.txt
```

### Step 5: Set API Keys

The config/settings.py file will prompt you for your API keys when main.py is run for the first time.

    OpenAI API Key: You will be prompted to enter your OpenAI API key.

    LangSmith API Key: You will be prompted to enter your LangSmith API key. LangSmith tracing is enabled by default for observability.

Alternatively, you can set these as environment variables before running the script:

```bash
export OPENAI_API_KEY="your_openai_api_key_here"
export LANGSMITH_API_KEY="your_langsmith_api_key_here"
```

### Step 6: Run the Application

Execute the main.py script from the rag_pipeline/ directory:

``` bash
python main.py
```

The program will:

    Prompt for API keys if not already set.

    Initialize the LLM, embeddings, and vector store.

    Load documents from the specified URL, split them, and add them to the ChromaDB vector store (persisted in ./chroma_langchain_db). This step will be skipped if the vector store already contains documents.

    Invoke the RAG agent with a predefined question ("What is Task Decomposition?" and "Explain the concept of Tree of Thoughts.").

    Print the retrieved context and the generated answer.

### Step 7: Deactivate Virtual Environment (Optional)

When you are done, you can deactivate the virtual environment:

```bash
deactivate
```
