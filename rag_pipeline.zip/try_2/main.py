from data_loader.load_data import DataLoader
from vector_store.vectore_store import Embedding, VectorStore
import yaml
from dotenv import load_dotenv
load_dotenv()


settings_file = "/home/genai/narasim_ai/practice/rag_pipeline/try_2/config.yaml"
with open(settings_file, 'r') as f:
    config_info = yaml.safe_load(f)

# print(config_info['settings']['directory_path'])
data_loader_obj = DataLoader(config_info['data_settings']['directory_path'])
data_loader_obj.create_loaders()
data_loader_obj.collect_all_docs()
all_documents = data_loader_obj.get_all_docs()
print(f"Loaded all the documents, total docs is {len(all_documents)}")


embedding_obj = Embedding(config_info['data_settings']['embedding_name'], config_info['data_settings']['embed_model_name'])
embeddings = embedding_obj.create_embed_model()
print("Embeddings created")

vector_store_obj = VectorStore(
    config_info['data_settings']['vector_store_loc'],
    embeddings,
    config_info['data_settings']['vector_store_name'],
    all_documents
)
vector_store = vector_store_obj.create_vector_store()
print("vector store created")

results = vector_store.similarity_search_with_score("HDFC Life Ahmedabad contact details?", k = 3)
for docu, score in results:
    print(docu)
    print(score)