from langchain_community.vectorstores import FAISS
from langchain_openai.embeddings import OpenAIEmbeddings
import os
from dotenv import load_dotenv
import getpass
import faiss


load_dotenv()

class VectorStore:
    def __init__(self, vector_store_loc: str, embed_model, vector_store_name, docs):
        self.vector_store_loc = vector_store_loc
        self.embed_model = embed_model
        self.vector_store_name = vector_store_name
        self.docs = docs
    
    def create_vector_store(self):
        if(self.vector_store_name.lower() == 'faiss'):
            self.vector_store = FAISS.from_documents(self.docs, self.embed_model)
            self.vector_store.save_local(self.vector_store_loc)
        return self.vector_store



class Embedding:
    def __init__(self, embedding_name: str, embed_model_name: str):
        self.embedding_name = embedding_name
        self.embed_model_name = embed_model_name
        

    def create_embed_model(self):
        
        if(self.embedding_name == 'OpenAIEmbeddings'):
            if not os.environ.get("OPENAI_API_KEY"):
                os.environ["OPENAI_API_KEY"] = getpass.getpass("Enter API key for OpenAI: ")
            self.embeddings = OpenAIEmbeddings(model = self.embed_model_name)
        return self.embeddings
    
    def get_embed_model(self):
        return self.embeddings

